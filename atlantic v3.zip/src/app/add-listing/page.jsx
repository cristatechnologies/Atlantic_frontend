import AddListingComponent from "@/components/AddLisitingComponent/page";

const addListing = () => {
  return <>
  <AddListingComponent />
  </>;
};

export default addListing;
