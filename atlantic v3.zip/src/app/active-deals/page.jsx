"use client";

import DailyDealsComponent from "@/components/DailyDealsComponent/page";

const ActiveDeals = () => {
  return (
    <>
      <DailyDealsComponent />
    </>
  );
};

export default ActiveDeals;
