import { tablelist_1, tablelist_2, tablelist_3, tablelist_4, tablelist_5, tablelist_6, tablelist_7, tablelist_8 } from "../imagepath";



export default {
    Mylistings: [
        {
            id: 1,
            image:tablelist_1,
            content:"Villa 457 sq.m. In Benidorm Fully Qquipped House",
            titles:"Electronics",
            status:"Published",
            bg:"status-text",
            numbers:1523,
            class:"action"
             
            

        },
        {
            id: 2,
            image:tablelist_2,
            content:"CDL A OTR Compnay Driver Job-N",
            titles:"Electronics",
            status:"Published",
            bg:"status-text",
            numbers:1523,
            class:"action"
            

        },
        {
            id: 3,
            image:tablelist_3,
            content:"HP Gaming 15.6 Touchscren 12G",
            titles:"Electronics",
            status:"Published",
            bg:"status-text",
            numbers:1523,
            class:"action"
            

        },
        {
            id: 4,
            image:tablelist_4,
            content:"2012 AudiR8 GT Spider Convrtibile",
            titles:"Electronics",
            status:"Published",
            bg:"status-text",
            numbers:1523,
            class:"action"
            

        },
        {
            id: 5,
            image:tablelist_5,
            content:"2017 Gulfsteam Ameri-Lite",
            titles:"Electronics",
            status:"Published",
            bg:"status-text",
            numbers:1523,
            class:"action"

        },
        {
            id: 6,
            image:tablelist_6,
            content:"Fashion Luxury Men Date",
            titles:"Electronics",
            status:"Published",
            bg:"status-text",
            numbers:1523,
            class:"action"
            

        },
        {
            id: 7,
            image:tablelist_7,
            content:"Apple iPhone 6 16GB 4G LTE",
            titles:"Electronics",
            status:"Published",
            bg:"status-text",
            numbers:1523,
            class:"action"
            

        },
        {
            id: 8,
            image:tablelist_8,
            content:"Customized Apple iMac 21.5″ All-In",
            titles:"Electronics",
            status:"Un Published",
            bg:"status-text unpublish",
            numbers:1523,
            class:"action"
            

        }
        
        


    ]

}





