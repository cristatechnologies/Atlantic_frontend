




// export { default as Home03 } from "/public/img/home-03.jpg";
// export { default as Home04 } from "/public/img/home-04.jpg";
// export { default as Home05 } from "/public/img/home-05.jpg";
// export { default as Home06 } from "/public/img/home-06.jpg";
// export { default as Home07 } from "/public/img/home-07.jpg";
// export { default as Home08 } from "/public/img/home-08.jpg";
// export { default as Home09 } from "/public/img/home-09.jpg";


export { default as feature_text_logo } from "/public/img/featured/feature-text-logo.png";


export { default as top_rent_room_img_1 } from "/public/img/gallery/top-rent-room-img-1.jpg";
export { default as top_rent_room_img_2 } from "/public/img/gallery/top-rent-room-img-2.jpg";
// export { default as top_rent_room_img_3 } from "/public/img/gallery/top-rent-room-img-3.jpg";
// export { default as top_rent_room_img_4 } from "/public/img/gallery/top-rent-room-img-4.jpg";

export { default as RightImg } from "/public/img/Right-img.png";
export { default as BannerEllipse } from "/public/img/bannerellipse.png";
export { default as ArrowBanner } from "/public/img/arrow-banner.png";
export { default as BannerArrow } from "/public/img/banner-arrow.png";

export { default as error404 } from "/public/img/404-error.jpg";
export { default as error504 } from "/public/img/505error.jpg";

export { default as work1_jpg } from "/public/img/icons/work1.jpg";
export { default as work2_jpg } from "/public/img/icons/work2.jpg";
export { default as work3_jpg } from "/public/img/icons/work3.jpg";

export { default as Category1Svg } from "/public/img/icons/category-1.svg";
export { default as Category2Svg } from "/public/img/icons/category-2.svg";
export { default as Category3Svg } from "/public/img/icons/category-3.svg";
export { default as Category4Svg } from "/public/img/icons/category-4.svg";
export { default as Category5Svg } from "/public/img/icons/category-5.svg";
export { default as Category6Svg } from "/public/img/icons/category-6.svg";
export { default as Category7Svg } from "/public/img/icons/category-7.svg";
export { default as Category8Svg } from "/public/img/icons/category-8.svg";
export { default as Category9Svg } from "/public/img/icons/category-9.svg";
export { default as Category10Svg } from "/public/img/icons/category-10.svg";
export { default as Category11Svg } from "/public/img/icons/category-11.svg";
export { default as Category12Svg } from "/public/img/icons/category-12.svg";
export { default as Category18Svg } from "/public/img/icons/category-18.svg";
export { default as Category19Svg } from "/public/img/icons/category-19.svg";
export { default as Category20Svg } from "/public/img/icons/category-20.svg";
export { default as Category21Svg } from "/public/img/icons/category-21.svg";
export { default as Category22Svg } from "/public/img/icons/category-22.svg";
export { default as Category23Svg } from "/public/img/icons/category-23.svg";
export { default as Category24Svg } from "/public/img/icons/category-24.svg";
export { default as Category25Svg } from "/public/img/icons/category-25.svg";
export { default as Category26Svg } from "/public/img/icons/category-26.svg";
export { default as Category27Svg } from "/public/img/icons/category-27.svg";
export { default as Category28Svg } from "/public/img/icons/category-28.svg";

export { default as service_1 } from "/public/img/icons/service-1.svg";
export { default as service_2 } from "/public/img/icons/service-2.svg";
export { default as service_3 } from "/public/img/icons/service-3.svg";
export { default as service_4 } from "/public/img/icons/service-4.svg";
export { default as service_5 } from "/public/img/icons/service-5.svg";
export { default as service_6 } from "/public/img/icons/service-6.svg";

export { default as area_icon } from "/public/img/icons/area-icon.svg";
export { default as bed_icon } from "/public/img/icons/bed-icon.svg";
export { default as bath_icon } from "/public/img/icons/bath-icon.svg";
export { default as floor_icon } from "/public/img/icons/floor-icon.svg";
export { default as guest_icon } from "/public/img/icons/guest-icon.svg";

export { default as Feature1 } from "/public/img/featured/feature-1.jpg";
export { default as Feature2 } from "/public/img/featured/feature-2.jpg";
export { default as Feature3 } from "/public/img/featured/feature-3.jpg";
export { default as Feature4 } from "/public/img/featured/feature-4.jpg";
export { default as Feature5 } from "/public/img/featured/feature-5.jpg";
export { default as Feature6 } from "/public/img/featured/feature-6.jpg";
export { default as Feature7 } from "/public/img/featured/feature-7.jpg";
export { default as Feature8 } from "/public/img/featured/feature-8.jpg";
export { default as Feature9 } from "/public/img/featured/feature-9.jpg";
export { default as ProfileAvatar01 } from "/public/img/profiles/avatar-01.jpg";
export { default as ProfileAvatar02 } from "/public/img/profiles/avatar-02.jpg";
export { default as ProfileAvatar03 } from "/public/img/profiles/avatar-03.jpg";
export { default as ProfileAvatar04 } from "/public/img/profiles/avatar-04.jpg";
export { default as ProfileAvatar05 } from "/public/img/profiles/avatar-05.jpg";
export { default as ProfileAvatar06 } from "/public/img/profiles/avatar-06.jpg";
export { default as ProfileAvatar07 } from "/public/img/profiles/avatar-07.jpg";
export { default as ProfileAvatar08 } from "/public/img/profiles/avatar-08.jpg";
export { default as ProfileAvatar09 } from "/public/img/profiles/avatar-09.jpg";
export { default as ProfileAvatar10 } from "/public/img/profiles/avatar-10.jpg";
export { default as ProfileAvatar11 } from "/public/img/profiles/avatar-11.jpg";
export { default as ProfileAvatar12 } from "/public/img/profiles/avatar-12.jpg";
export { default as ProfileAvatar13 } from "/public/img/profiles/avatar-13.jpg";
export { default as ProfileAvatar14 } from "/public/img/profiles/avatar-14.jpg";

export { default as PopularImg } from "/public/img/popular-img.png";
export { default as LocationsUsa } from "/public/img/locations/usa.jpg";
export { default as LocationsCanada } from "/public/img/locations/canada.jpg";
export { default as LocationsChina } from "/public/img/locations/china.jpg";
export { default as LocationsUk } from "/public/img/locations/uk.jpg";
export { default as LocationsAustralia } from "/public/img/locations/australia.jpg";
export { default as LocationsFrance } from "/public/img/locations/france.jpg";

export { default as CtaImg } from "/public/img/cta-img.png";
export { default as calendersvg } from "/public/img/icons/calender.svg";
export { default as usersvg } from "/public/img/icons/users.svg";
export { default as testimonal_bg } from "/public/img/bg/testimonal-bg.png";

export { default as Quotes } from "/public/img/quotes.png";
export { default as footer_six_bg } from "/public/img/footer-six-bg.png";

export { default as gallerypop_1 } from "/public/img/gallery/gallery2/gallerypop-1.jpg";
export { default as gallerypop_2 } from "/public/img/gallery/gallery2/gallerypop-2.jpg";
export { default as gallerypop_3 } from "/public/img/gallery/gallery2/gallerypop-3.jpg";
export { default as gallerypop_4 } from "/public/img/gallery/gallery2/gallerypop-4.jpg";
export { default as gallerypop_5 } from "/public/img/gallery/gallery2/gallerypop-5.jpg";
export { default as gallerypop_6 } from "/public/img/gallery/gallery2/gallerypop-6.jpg";
export { default as gallerypop_7 } from "/public/img/gallery/gallery2/gallerypop-7.jpg";
export { default as gallerypop_8 } from "/public/img/gallery/gallery2/gallerypop-8.jpg";
export { default as gallerypop_9 } from "/public/img/gallery/gallery2/gallerypop-9.jpg";
export { default as gallerypop_10 } from "/public/img/gallery/gallery2/gallerypop-10.jpg";
export { default as gallerypop_12 } from "/public/img/gallery/gallery2/gallerypop-12.jpg";

export { default as galleryimage_1 } from "/public/img/gallery/gallery2/galleryimage-1.jpg";
export { default as galleryimage_2 } from "/public/img/gallery/gallery2/galleryimage-2.jpg";
export { default as galleryimage_3 } from "/public/img/gallery/gallery2/galleryimage-3.jpg";
export { default as galleryimage_4 } from "/public/img/gallery/gallery2/galleryimage-4.jpg";
export { default as galleryimage_5 } from "/public/img/gallery/gallery2/galleryimage-5.jpg";
export { default as galleryimage_6 } from "/public/img/gallery/gallery2/galleryimage-6.jpg";
export { default as galleryimage_7 } from "/public/img/gallery/gallery2/galleryimage-7.jpg";
export { default as galleryimage_8 } from "/public/img/gallery/gallery2/galleryimage-8.jpg";
export { default as galleryimage_9 } from "/public/img/gallery/gallery2/galleryimage-9.jpg";
export { default as galleryimage_10 } from "/public/img/gallery/gallery2/galleryimage-10.jpg";
export { default as galleryimage_12 } from "/public/img/gallery/gallery2/galleryimage-12.jpg";

export { default as partners_1 } from "/public/img/partners/partners-1.png";
export { default as partners_2 } from "/public/img/partners/partners-2.png";
export { default as partners_3 } from "/public/img/partners/partners-3.png";
export { default as partners_4} from "/public/img/partners/partners-4.png";
export { default as partners_5 } from "/public/img/partners/partners-5.png";
export { default as partners_6 } from "/public/img/partners/partners-6.png";

export { default as Testimonial1 } from "/public/img/testimonial-1.jpg";
export { default as Testimonial2 } from "/public/img/testimonial-2.jpg";
export { default as test_bg } from "/public/img/test-bg.png";
export { default as contactleftimg } from "/public/img/contactleftimg.jpg";
export { default as contactform_img } from "/public/img/contactform-img.svg";
export { default as apple } from "/public/img/apple.svg";
export { default as google } from "/public/img/google.svg";
export { default as facebook } from "/public/img/facebook.svg";

export { default as Partners1 } from "/public/img/partners/partners-1.svg";
export { default as Partners2 } from "/public/img/partners/partners-2.svg";
export { default as Partners3 } from "/public/img/partners/partners-3.svg";
export { default as Partners4 } from "/public/img/partners/partners-4.svg";
export { default as Partners5 } from "/public/img/partners/partners-5.svg";
export { default as Partners6 } from "/public/img/partners/partners-6.svg";

export { default as Blog1 } from "/public/img/blog/blog-1.jpg";
export { default as Blog2 } from "/public/img/blog/blog-2.jpg";
export { default as Blog3 } from "/public/img/blog/blog-3.jpg";
export { default as Blog4 } from "/public/img/blog/blog-4.jpg";
export { default as Blog5 } from "/public/img/blog/blog-5.jpg";
export { default as Blog6 } from "/public/img/blog/blog-6.jpg";
export { default as Blog7 } from "/public/img/blog/blog-7.jpg";
export { default as Blog8 } from "/public/img/blog/blog-8.jpg";
export { default as Blog9 } from "/public/img/blog/blog-9.jpg";
export { default as Blog10 } from "/public/img/blog/blog-10.jpg";
export { default as Blog11 } from "/public/img/blog/blog-11.jpg";
export { default as Blog12 } from "/public/img/blog/blog-12.jpg";
export { default as Blog13 } from "/public/img/blog/blog-13.jpg";
export { default as Blog14 } from "/public/img/blog/blog-14.jpg";
export { default as Blog15 } from "/public/img/blog/blog-15.jpg";
export { default as Blog16 } from "/public/img/blog/blog-16.jpg";
export { default as Blog17 } from "/public/img/blog/blog-17.jpg";
export { default as Blog18 } from "/public/img/blog/blog-18.jpg";
export { default as Blog19 } from "/public/img/blog/blog-19.jpg";

export { default as bloglistview_1 } from "/public/img/blog/bloglistview-1.jpg";
export { default as bloglistview_2 } from "/public/img/blog/bloglistview-2.jpg";
export { default as bloglistview_3 } from "/public/img/blog/bloglistview-3.jpg";
export { default as bloglistview_4 } from "/public/img/blog/bloglistview-4.jpg";



export { default as FooterLogo } from "/public/img/footerlogo.svg";
export { default as CallCallingSvg } from "/public/img/call-calling.svg";
export { default as SmsTracking } from "/public/img/sms-tracking.svg";
export { default as Amexpay } from "/public/img/amex-pay.svg";
export { default as Applepay } from "/public/img/apple-pay.svg";
export { default as Gpay } from "/public/img/gpay.svg";
export { default as Master } from "/public/img/master.svg";
export { default as Phone } from "/public/img/phone.svg";
export { default as Visa } from "/public/img/visa.svg";

// Home 2
export { default as BannerPng } from "/public/img/banner.png";
export { default as TitelImg } from "/public/img/title-img.png";
export { default as Service01 } from "/public/img/service/service-01.jpg";
export { default as Service02 } from "/public/img/service/service-02.jpg";
export { default as Service03 } from "/public/img/service/service-03.jpg";
export { default as Service04 } from "/public/img/service/service-04.jpg";

export { default as Celebrate } from "/public/img/celebrate.jpg";
export { default as Celebrate01 } from "/public/img/celebrate-01.jpg";

export { default as CategoryImg } from "/public/img/service/category-img.png";
export { default as Category01Jpg } from "/public/img/service/category-01.jpg";
export { default as Category02Jpg } from "/public/img/service/category-02.jpg";
export { default as Category03Jpg } from "/public/img/service/category-03.jpg";
export { default as Category04Jpg } from "/public/img/service/category-04.jpg";
export { default as Category05Jpg } from "/public/img/service/category-05.jpg";
export { default as Category06Jpg } from "/public/img/service/category-06.jpg";

export { default as CelebrateImg } from "/public/img/celebrate-img.png";
export { default as CelebratePng } from "/public/img/bg/celebrate.png";
export { default as CelebrateBg01 } from "/public/img/bg/celebration-bg-01.png";

export { default as Venue01 } from "/public/img/venues/venue-01.jpg";
export { default as Venue02 } from "/public/img/venues/venue-02.jpg";
export { default as Venue03 } from "/public/img/venues/venue-03.jpg";

export { default as TitleImgWhite } from "/public/img/title-img-white.png";
export { default as Couple01 } from "/public/img/bg/couple-01.png";
export { default as Couple02 } from "/public/img/bg/couple-02.png";
export { default as Couple03 } from "/public/img/bg/couple-03.png";

export { default as SuccessImg } from "/public/img/success-img.png";

export { default as WedIcon01 } from "/public/img/icons/wed-icon-01.svg";
export { default as WedIcon02 } from "/public/img/icons/wed-icon-02.svg";
export { default as WedIcon03 } from "/public/img/icons/wed-icon-03.svg";

export { default as Category1 } from "/public/img/category/category-01.jpg";
export { default as Category2 } from "/public/img/category/category-02.jpg";
export { default as Category3 } from "/public/img/category/category-03.jpg";
export { default as Category4 } from "/public/img/category/category-04.jpg";
export { default as Category5 } from "/public/img/category/category-05.jpg";

export { default as Gallery01 } from "/public/img/gallery/gallery-01.jpg";
export { default as Gallery02 } from "/public/img/gallery/gallery-02.jpg";
export { default as Gallery03 } from "/public/img/gallery/gallery-03.jpg";
export { default as Gallery04 } from "/public/img/gallery/gallery-04.jpg";
export { default as Gallery05 } from "/public/img/gallery/gallery-05.jpg";
export { default as Gallery06 } from "/public/img/gallery/gallery-06.jpg";

export { default as Timeline01 } from "/public/img/icons/timeline-01.svg";
export { default as Timeline02 } from "/public/img/icons/timeline-02.svg";
export { default as Timeline03 } from "/public/img/icons/timeline-03.svg";
export { default as Timeline04 } from "/public/img/icons/timeline-04.svg";
export { default as Timeline05 } from "/public/img/icons/timeline-05.svg";
export { default as Timeline06 } from "/public/img/icons/timeline-06.svg";
export { default as Timeline07 } from "/public/img/icons/timeline-07.svg";
export { default as job_logomark_1 } from "/public/img/icons/job-logomark-1.png";
export { default as job_logomark_2 } from "/public/img/icons/job-logomark-2.png";
export { default as job_logomark_3 } from "/public/img/icons/job-logomark-3.png";
export { default as job_logomark_4 } from "/public/img/icons/job-logomark-4.png";
export { default as job_logomark_5 } from "/public/img/icons/job-logomark-5.png";
export { default as job_logomark_6 } from "/public/img/icons/job-logomark-6.png";
export { default as why_us_1 } from "/public/img/icons/why-us-1.svg";
export { default as why_us_2 } from "/public/img/icons/why-us-2.svg";
export { default as why_us_3 } from "/public/img/icons/why-us-3.svg";
export { default as why_us_4} from "/public/img/icons/why-us-4.svg";

export { default as Stripe } from "/public/img/icons/stripe.svg";
export { default as Discover } from "/public/img/icons/discover.svg";
export { default as Master01 } from "/public/img/icons/master-01.svg";
export { default as Visa01 } from "/public/img/icons/visa-01.svg";
//export { default as property } from "/public/img/icons/property.png";

// Home 3
export { default as BalloonImg } from "/public/img/bg/balloon-img.png";
export { default as Cloud01 } from "/public/img/bg/cloud-01.png";
export { default as Cloud02 } from "/public/img/bg/cloud-02.png";
export { default as why_us_bg } from "/public/img/bg/why-us-bg.png";
export { default as Banner02 } from "/public/img/banner-02.png";
export { default as PlanePng } from "/public/img/bg/plane.png";
export { default as BannerBtmImg } from "/public/img/banner-btm-img.png";
export { default as popular_bg_1 } from "/public/img/popular-bg-1.png";
export { default as popular_bg_2 } from "/public/img/popular-bg-2.png";
export { default as counter_bg } from "/public/img/bg/counter-bg.png";
export { default as ads_1 } from "/public/img/ads-1.png";
export { default as holiday_cabin_slider } from "/public/img/bg/holiday-cabin-slider-img-1.jpg";
export { default as holiday_cabin_slider_2 } from "/public/img/bg/holiday-cabin-slider-img-2.jpg";



export { default as Destination1 } from "/public/img/recommended/destination-01.jpg";
export { default as Destination2 } from "/public/img/recommended/destination-02.jpg";
export { default as Destination3 } from "/public/img/recommended/destination-03.jpg";
export { default as Destination4 } from "/public/img/recommended/destination-04.jpg";

export { default as best_room_img_1 } from "/public/img/featured/best-room-img-1.jpg";
export { default as best_room_img_2 } from "/public/img/featured/best-room-img-2.jpg";
export { default as best_room_img_3 } from "/public/img/featured/best-room-img-3.jpg";
export { default as best_room_img_4 } from "/public/img/featured/best-room-img-4.jpg";

export { default as ServiceImg } from "/public/img/service-img.png";
export { default as ServiceIcon1 } from "/public/img/services/icon-1.png";
export { default as ServiceIcon2 } from "/public/img/services/icon-2.png";
export { default as ServiceIcon3 } from "/public/img/services/icon-3.png";
export { default as ServiceIcon4 } from "/public/img/services/icon-4.png";

export { default as DesignationImg1 } from "/public/img/designation-img1.jpg";
export { default as DesignationImg2 } from "/public/img/designation-img2.jpg";

export { default as Recommend1 } from "/public/img/recommended/recommand-01.jpg";
export { default as Recommend2 } from "/public/img/recommended/recommand-02.jpg";
export { default as Recommend3 } from "/public/img/recommended/recommand-03.jpg";
export { default as Recommend4 } from "/public/img/recommended/recommand-04.jpg";

export { default as TripIcon1 } from "/public/img/icons/trip-icon-01.svg";
export { default as TripIcon2 } from "/public/img/icons/trip-icon-02.svg";
export { default as TripIcon3 } from "/public/img/icons/trip-icon-03.svg";
export { default as TripIcon4 } from "/public/img/icons/trip-icon-04.svg";
export { default as TripIcon5 } from "/public/img/icons/trip-icon-05.svg";
export { default as TripIcon6 } from "/public/img/icons/trip-icon-06.svg";
export { default as TripIcon7 } from "/public/img/icons/trip-icon-07.svg";
export { default as TripIcon8 } from "/public/img/icons/trip-icon-08.svg";
export { default as TripIcon9 } from "/public/img/icons/trip-icon-09.svg";
export { default as TripIcon10 } from "/public/img/icons/trip-icon-10.svg";

export { default as Gallery1Jpg } from "/public/img/recommended/gallery-1.jpg";
export { default as Gallery2Jpg } from "/public/img/recommended/gallery-2.jpg";
export { default as Gallery3Jpg } from "/public/img/recommended/gallery-3.jpg";
export { default as Gallery4Jpg } from "/public/img/recommended/gallery-4.jpg";

export { default as Blog1Jpg } from "/public/img/blog-1.jpg";
export { default as Blog2Jpg } from "/public/img/blog-2.jpg";
export { default as Blog3Jpg } from "/public/img/blog-3.jpg";
export { default as Blog4Jpg } from "/public/img/blog-4.jpg";

export { default as TestiCirlce1 } from "/public/img/testi-circle1.png";
export { default as TestiCirlce2 } from "/public/img/testi-circle2.png";
export { default as TestiCirlce3 } from "/public/img/testi-circle3.png";
export { default as TestiCirlce4 } from "/public/img/testi-circle4.png";

export { default as EarthIcon } from "/public/img/earth-icon.png";

export { default as SubscribeBg } from "/public/img/subscribe-bg.png";
export { default as MailCheck } from "/public/img/mail-check.png";

export { default as Activity1 } from "/public/img/activity-1.jpg";
export { default as Activity2 } from "/public/img/activity-2.jpg";
export { default as Activity3 } from "/public/img/activity-3.jpg";
export { default as Activity4 } from "/public/img/activity-4.jpg";
export { default as Activity5 } from "/public/img/activity-5.jpg";
export { default as Activity6 } from "/public/img/activity-6.jpg";
export { default as Activity7 } from "/public/img/activity-7.jpg";

export { default as statistic_icon } from "/public/img/statistic-icon.svg";
export { default as galleryicon } from "/public/img/galleryicon.svg";
export { default as details_icon } from "/public/img/details-icon.svg";
export { default as category_icon } from "/public/img/category-icon.svg";

export { default as blogdetailimg_1 } from "/public/img/blog/blogdetailimg-1.jpg";
export { default as blogdetailimg_2 } from "/public/img/blog/blogdetailimg-2.jpg";

export { default as reviewsvg } from "/public/img/review.svg";
export { default as blogquote } from "/public/img/blogquote.jpg";


export { default as bloglistimg_1 } from "/public/img/blog/bloglistimg-1.jpg";
export { default as bloglistimg_2 } from "/public/img/blog/bloglistimg-2.jpg";
export { default as bloglistimg_3 } from "/public/img/blog/bloglistimg-3.jpg";
export { default as bloglistimg_4 } from "/public/img/blog/bloglistimg-4.jpg";
export { default as bloglistimg_5 } from "/public/img/blog/bloglistimg-5.jpg";
export { default as bloglistimg_6 } from "/public/img/blog/bloglistimg-6.jpg";
export { default as bloglistimg_7 } from "/public/img/blog/bloglistimg-7.jpg";
export { default as bloglistimg_8 } from "/public/img/blog/bloglistimg-8.jpg";

export { default as GalleryImg1 } from "/public/img/gallery/galleryimg-1.jpg";
export { default as GalleryImg2 } from "/public/img/gallery/galleryimg-2.jpg";
export { default as GalleryImg9 } from "/public/img/gallery/galleryimg-9.jpg";
export { default as GalleryImg10 } from "/public/img/gallery/galleryimg-10.jpg";
export { default as GalleryImg3 } from "/public/img/gallery/galleryimg-3.jpg";
export { default as GalleryImg11 } from "/public/img/gallery/galleryimg-11.jpg";

export { default as gallery_11 } from "/public/img/gallery/gallery1/gallery-11.jpg";
export { default as gallery_09 } from "/public/img/gallery/gallery1/gallery-9.jpg";
export { default as gallery_10 } from "/public/img/gallery/gallery1/gallery-10.jpg";

export { default as banner_img_1 } from "/public/img/banner/banner-img-1.png";
export { default as banner_img_2 } from "/public/img/banner/banner-img-2.png";
export { default as banner_img_3 } from "/public/img/banner/banner-img-3.png";
export { default as banner_img_4 } from "/public/img/banner/banner-img-4.png";
export { default as banner_left_bg } from "/public/img/bg/banner-left-bg.png";
export { default as banner_right_bg } from "/public/img/bg/banner-right-bg.png";
export { default as banner_bottom_bg } from "/public/img/bg/banner-bottom-bg.png";

// Home4
export { default as BannerImg4 } from "/public/img/banner/banner-img-04.png";

export { default as CategoryIcon1 } from "/public/img/icons/category-icon-01.svg";
export { default as CategoryIcon2 } from "/public/img/icons/category-icon-02.svg";
export { default as CategoryIcon3 } from "/public/img/icons/category-icon-03.svg";
export { default as CategoryIcon13 } from "/public/img/icons/category-13.svg";
export { default as CategoryIcon14 } from "/public/img/icons/category-14.svg";
export { default as CategoryIcon15 } from "/public/img/icons/category-15.svg";
export { default as CategoryIcon16 } from "/public/img/icons/category-16.svg";
export { default as CategoryIcon17 } from "/public/img/icons/category-17.svg";

export { default as rating } from "/public/img/icons/rating.svg";
export { default as chat } from "/public/img/icons/chat.svg";
export { default as bookmark } from "/public/img/icons/bookmark.svg";
export { default as verified } from "/public/img/icons/verified.svg";

export { default as profile_img } from "/public/img/profile-img.jpg";

export { default as bloglistingimg_1 } from "/public/img/blog/bloglistingimg-1.jpg";
export { default as bloglistingimg_2 } from "/public/img/blog/bloglistingimg-2.jpg";
export { default as bloglistingimg_3 } from "/public/img/blog/bloglistingimg-3.jpg";

export { default as Cowork1 } from "/public/img/cowork-01.png";
export { default as Cowork2 } from "/public/img/cowork-02.png";
export { default as Cowork3 } from "/public/img/cowork-03.png";

export { default as Work1 } from "/public/img/work/work-01.jpg";
export { default as Work2 } from "/public/img/work/work-02.jpg";
export { default as Work3 } from "/public/img/work/work-03.jpg";
export { default as Work4 } from "/public/img/work/work-04.jpg";

export { default as WorkCity1 } from "/public/img/work/city-01.jpg";
export { default as WorkCity2 } from "/public/img/work/city-02.jpg";
export { default as WorkCity3 } from "/public/img/work/city-03.jpg";
export { default as WorkCity4 } from "/public/img/work/city-04.jpg";
export { default as WorkCity5 } from "/public/img/work/city-05.jpg";
export { default as WorkCity6 } from "/public/img/work/city-06.jpg";

export { default as SpaceImg } from "/public/img/space-img.png";

export { default as about_img } from "/public/img/about-img.jpg";
export { default as cta_img } from "/public/img/cta-img.png";
export { default as quotes } from "/public/img/quotes.png";

export { default as london_1 } from "/public/img/locations/london-1.jpg";
export { default as usa_1 } from "/public/img/locations/usa-1.jpg";
export { default as canada_1 } from "/public/img/locations/canada-1.jpg";
export { default as china_1 } from "/public/img/locations/china-1.jpg";
export { default as uk_1 } from "/public/img/locations/uk-1.jpg";
export { default as australia_1 } from "/public/img/locations/australia-1.jpg";
export { default as france_1 } from "/public/img/locations/france-1.jpg";

export { default as Business1 } from "/public/img/business/business-01.jpg";
export { default as Business2 } from "/public/img/business/business-02.jpg";
export { default as Business3 } from "/public/img/business/business-03.jpg";
export { default as Business4 } from "/public/img/business/business-04.jpg";

export { default as City1 } from "/public/img/city/city-01.jpg";
export { default as City2 } from "/public/img/city/city-02.jpg";
export { default as City3 } from "/public/img/city/city-03.jpg";
export { default as City4 } from "/public/img/city/city-04.jpg";

export { default as FeaturePng } from "/public/img/feature.png";

export { default as business_team_1 } from "/public/img/business/team-1.jpg";
export { default as business_team_2 } from "/public/img/business/team-2.jpg";
export { default as business_team_3 } from "/public/img/business/team-3.jpg";
export { default as business_team_4 } from "/public/img/business/team-4.jpg";
export { default as business_team_5 } from "/public/img/business/team-5.jpg";

export { default as Gallery1 } from "/public/img/gallery/gallery-1.jpg";
export { default as Gallery2 } from "/public/img/gallery/gallery-2.jpg";
export { default as Gallery3 } from "/public/img/gallery/gallery-3.jpg";
export { default as Gallery4 } from "/public/img/gallery/gallery-4.jpg";
export { default as Gallery5 } from "/public/img/gallery/gallery-5.jpg";

export { default as Latest1 } from "/public/img/latest/latest-01.jpg";
export { default as Latest2 } from "/public/img/latest/latest-02.jpg";
export { default as Latest3 } from "/public/img/latest/latest-03.jpg";
export { default as Latest4 } from "/public/img/latest/latest-04.jpg";

export { default as SearchIcon } from "/public/img/icons/search-icon.svg";
export { default as LogoWhiteSvg } from "/public/img/logo-white.svg";

export { default as BannerSixBg1 } from "/public/img/bg/banner-six-bg-1.png";
export { default as BannerSixBg2 } from "/public/img/bg/banner-six-bg-2.png";
export { default as Car } from "/public/img/car.png";
export { default as CarIcon } from "/public/img/icons/car-icon.svg";

export { default as WhiteSearch } from "/public/img/icons/white-search.svg";
export { default as TitleSvg } from "/public/img/icons/title.svg";
export { default as bx_repost } from "/public/img/icons/bx-repost.svg";
export { default as bx_trophy } from "/public/img/icons/bx-trophy.svg";
export { default as bx_power_off } from "/public/img/icons/bx-power-off.svg";
export { default as bx_gift } from "/public/img/icons/bx-gift.svg";
export { default as bx_planet } from "/public/img/icons/bx-planet.svg";
export { default as bx_pie_chart } from "/public/img/icons/bx-pie-chart.svg";
export { default as bx_map_pin } from "/public/img/icons/bx-map-pin.svg";
export { default as bx_wrench } from "/public/img/icons/bx-wrench.svg";

export { default as TrendingCar1 } from "/public/img/work/trending-car-1.jpg";
export { default as TrendingCar2 } from "/public/img/work/trending-car-2.jpg";
export { default as TrendingCar3 } from "/public/img/work/trending-car-3.jpg";
export { default as TrendingCar4 } from "/public/img/work/trending-car-4.jpg";
export { default as TrendingCar5 } from "/public/img/work/trending-car-5.jpg";

export { default as CarClass1 } from "/public/img/cars-class-1.png";
export { default as CarClass2 } from "/public/img/cars-class-2.png";
export { default as CarClass3 } from "/public/img/cars-class-3.png";
export { default as CarClass4 } from "/public/img/cars-class-4.png";
export { default as CarClass5 } from "/public/img/cars-class-5.png";
export { default as CarClass6 } from "/public/img/cars-class-6.png";

export { default as BrandBg } from "/public/img/brand-bg.png";
export { default as BrandBg2 } from "/public/img/brand-bg-2.png";
export { default as logo_new } from "/public/img/logo-new.png";

export { default as Brand1 } from "/public/img/partners/brand-1.png";
export { default as Brand2 } from "/public/img/partners/brand-2.png";
export { default as Brand3 } from "/public/img/partners/brand-3.png";
export { default as Brand4 } from "/public/img/partners/brand-4.png";
export { default as Brand5 } from "/public/img/partners/brand-5.png";
export { default as Brand6 } from "/public/img/partners/brand-6.png";

export { default as FeatureCar1 } from "/public/img/featured/feature-car-1.jpg";
export { default as FeatureCar2 } from "/public/img/featured/feature-car-2.jpg";
export { default as FeatureCar3 } from "/public/img/featured/feature-car-3.jpg";
export { default as FeatureCar4 } from "/public/img/featured/feature-car-4.png";

export { default as CarRental1 } from "/public/img/car-rental-slider-img.jpg";
export { default as CarRental2 } from "/public/img/car-rental-slider-img-2.jpg";
export { default as Polygon } from "/public/img/Polygon.svg";
export { default as become_dealer_bg } from "/public/img/become-dealer-bg.png";

export { default as heading_logo } from "/public/img/heading-logo.png";
export { default as footer_logo_nine } from "/public/img/footer-logo-nine.svg";
export { default as footer_bg } from "/public/img/bg/footer-bg.png";
export { default as agent_bg } from "/public/img/bg/agent-bg.png";
export { default as website } from "/public/img/website.svg";

export { default as mediaimg_2} from "/public/img/mediaimg-2.jpg";
export { default as mediaimg_1} from "/public/img/mediaimg-1.jpg";

export { default as gallerymedia_1} from "/public/img/gallery/gallerymedia-1.jpg";
export { default as gallerymedia_2} from "/public/img/gallery/gallerymedia-2.jpg";
export { default as gallerymedia_3} from "/public/img/gallery/gallerymedia-3.jpg";
export { default as gallerymedia_4} from "/public/img/gallery/gallerymedia-4.jpg";
export { default as gallerymedia_5} from "/public/img/gallery/gallerymedia-5.jpg";


export { default as car_img } from "/public/img/car-img.jpg";
export { default as amsterdam } from "/public/img/amsterdam.jpg";
export { default as foodhabits } from "/public/img/foodhabits.jpg";
export { default as fashion } from "/public/img/fashion.jpg";
export { default as education } from "/public/img/education.jpg";
export { default as petanimal } from "/public/img/petanimal.jpg";
export { default as apple_phone } from "/public/img/apple-phone.jpg";

export { default as marker } from "/public/img//icons/marker.png";
export { default as marker1 } from "/public/img//icons/marker1.png";
export { default as marker2 } from "/public/img//icons/marker2.png";
export { default as marker3 } from "/public/img//icons/marker3.png";
export { default as marker4 } from "/public/img//icons/marker4.png";
export { default as marker5 } from "/public/img//icons/marker5.png";
export { default as marker6 } from "/public/img//icons/marker6.png";
export { default as marker7 } from "/public/img//icons/marker7.png";

export { default as listgrid_1 } from "/public/img/list/listgrid-1.jpg";
export { default as listgrid_2 } from "/public/img/list/listgrid-2.jpg";
export { default as listgrid_3 } from "/public/img/list/listgrid-3.jpg";
export { default as listgrid_4 } from "/public/img/list/listgrid-4.jpg";
export { default as listgrid_5 } from "/public/img/list/listgrid-5.jpg";
export { default as listgrid_6 } from "/public/img/list/listgrid-6.jpg";
export { default as listgrid_7 } from "/public/img/list/listgrid-7.jpg";
export { default as listgrid_8 } from "/public/img/list/listgrid-8.jpg";

export { default as Feature_1_svg } from "/public/img//featured/Feature-1.svg";
export { default as Feature_2_svg } from "/public/img//featured/Feature-2.svg";
export { default as Feature_3_svg } from "/public/img//featured/Feature-3.svg";
export { default as Feature_4_svg } from "/public/img//featured/Feature-4.svg";
export { default as Feature_5_svg } from "/public/img//featured/Feature-5.svg";
export { default as Feature_6_svg } from "/public/img//featured/Feature-6.svg";
export { default as Feature_7_svg } from "/public/img//featured/Feature-7.svg";
export { default as Feature_8_svg } from "/public/img//featured/Feature-8.svg";


export { default as gallery_1_jpg } from "/public/img/gallery/gallery1/gallery-1.jpg";
export { default as gallery_2_jpg } from "/public/img/gallery/gallery1/gallery-2.jpg";
export { default as gallery_3_jpg } from "/public/img/gallery/gallery1/gallery-3.jpg";
export { default as gallery_4_jpg } from "/public/img/gallery/gallery1/gallery-4.jpg";
export { default as gallery_5_jpg } from "/public/img/gallery/gallery1/gallery-5.jpg";
export { default as gallery_6_jpg } from "/public/img/gallery/gallery1/gallery-6.jpg";
export { default as gallery_8_jpg } from "/public/img/gallery/gallery1/gallery-8.jpg";
export { default as gallery_7_jpg } from "/public/img/gallery/gallery1/gallery-7.jpg";



export { default as car_location_1 } from "/public/img/city/car-location-1.png";
export { default as car_location_2 } from "/public/img/city/car-location-2.png";
export { default as car_location_3 } from "/public/img/city/car-location-3.png";
export { default as car_location_4 } from "/public/img/city/car-location-4.png";
export { default as car_location_5 } from "/public/img/city/car-location-5.png";
export { default as car_location_6 } from "/public/img/city/car-location-6.png";

export { default as property_blog_1 } from "/public/img/blog/property-blog-1.jpg";
export { default as property_blog_2 } from "/public/img/blog/property-blog-2.jpg";
export { default as property_blog_3 } from "/public/img/blog/property-blog-3.jpg";


export { default as avatar_15 } from "/public/img/profiles/avatar-15.jpg";
export { default as avatar_16 } from "/public/img/profiles/avatar-16.jpg";
export { default as avatar_17 } from "/public/img/profiles/avatar-17.jpg";
export { default as avatar_18 } from "/public/img/profiles/avatar-18.jpg";
export { default as avatar_11 } from "/public/img/profiles/avatar-11.jpg";


export { default as blog_six_1 } from "/public/img/blog/blog-six-1.png";
export { default as blog_six_2 } from "/public/img/blog/blog-six-2.png";
export { default as blog_six_3 } from "/public/img/blog/blog-six-3.png";


export { default as category_img_1 } from "/public/img/latest/category-img-1.png";
export { default as category_img_2 } from "/public/img/latest/category-img-2.png";
export { default as category_img_3 } from "/public/img/latest/category-img-3.png";
export { default as category_img_4 } from "/public/img/latest/category-img-4.png";
export { default as category_img_5 } from "/public/img/latest/category-img-5.png";
export { default as category_img_6 } from "/public/img/latest/category-img-6.png";

export { default as cities_1 } from "/public/img/city/cities-1.jpg";
export { default as cities_2 } from "/public/img/city/cities-2.jpg";
export { default as cities_3 } from "/public/img/city/cities-3.jpg";
export { default as cities_4 } from "/public/img/city/cities-4.jpg";
export { default as cities_5 } from "/public/img/city/cities-5.jpg";
export { default as cities_6 } from "/public/img/city/cities-6.jpg";

export { default as blog_seven1 } from "/public/img/blog/blog-seven1.jpg";
export { default as blog_seven2 } from "/public/img/blog/blog-seven2.jpg";
export { default as blog_seven3 } from "/public/img/blog/blog-seven3.jpg";

export { default as heading_logo_small } from "/public/img/heading-logo-small.png";
export { default as main_img } from "/public/img/main-img.jpg";
export { default as content_img } from "/public/img/content-img.png";
export { default as cate_bg_1 } from "/public/img/cate-bg-1.png";
export { default as cate_bg_2 } from "/public/img/cate-bg-2.png";
export { default as eye } from "/public/img/eye.svg";
export { default as chatsearch } from "/public/img/chatsearch.svg";
export { default as chat_attachment } from "/public/img/chat-attachment.jpg";
// export { default as profile_img } from "/public/img/profile-img.jpg";

export { default as review_1 } from "/public/img/gallery/review-1.jpg";
export { default as review_2 } from "/public/img/gallery/review-2.jpg";
export { default as review_3 } from "/public/img/gallery/review-3.jpg";
export { default as review_4 } from "/public/img/gallery/review-4.jpg";

export { default as tablelist_1 } from "/public/img/list/tablelist-1.jpg";
export { default as tablelist_2 } from "/public/img/list/tablelist-2.jpg";
export { default as tablelist_3 } from "/public/img/list/tablelist-3.jpg";
export { default as tablelist_4 } from "/public/img/list/tablelist-4.jpg";
export { default as tablelist_5 } from "/public/img/list/tablelist-5.jpg";
export { default as tablelist_6 } from "/public/img/list/tablelist-6.jpg";
export { default as tablelist_7 } from "/public/img/list/tablelist-7.jpg";
export { default as tablelist_8 } from "/public/img/list/tablelist-8.jpg";


export { default as Restaurant_1 } from "/public/img/latest/Restaurant-1.jpg";
export { default as Restaurant_2 } from "/public/img/latest/Restaurant-2.jpg";
export { default as Restaurant_3 } from "/public/img/latest/Restaurant-3.jpg";
export { default as Restaurant_4 } from "/public/img/latest/Restaurant-4.jpg";
export { default as latest_restaurant_1 } from "/public/img/latest/latest-restaurant-1.jpg";
export { default as latest_restaurant_2 } from "/public/img/latest/latest-restaurant-2.jpg";
export { default as latest_restaurant_3 } from "/public/img/latest/latest-restaurant-3.jpg";
export { default as latest_restaurant_4 } from "/public/img/latest/latest-restaurant-4.jpg";


export { default as circle_11 } from "/public/img/banner/circle-11.png";
export { default as banner_left_bottom } from "/public/img/banner-left-bottom.png";
export { default as banner_right_bottom } from "/public/img/banner-right-bottom.png";
export { default as banner_left_bottom_shadow } from "/public/img/banner-left-bottom-shadow.png";
export { default as banner_right_bottom_shadow } from "/public/img/banner-right-bottom-shadow.png";
export { default as banner_center_bg } from "/public/img/banner-center-bg.png";
export { default as banner_middle } from "/public/img/banner-middle.png";
export { default as banner_top } from "/public/img/banner-top-bg.png";
export { default as pricing_bg } from "/public/img/pricing-bg.png";
export { default as main_banner_7 } from "/public/img/banner/main-banner-7.png";

export { default as icons_1 } from "/public/img/icons/icons-1.png";
export { default as icons_2 } from "/public/img/icons/icons-2.png";
export { default as icons_3 } from "/public/img/icons/icons-3.png";
export { default as icons_4 } from "/public/img/icons/icons-4.png";
export { default as icons_5 } from "/public/img/icons/icons-5.png";
export { default as icons_6 } from "/public/img/icons/icons-6.png";
export { default as icons_7 } from "/public/img/icons/icons-7.png";
export { default as icons_8 } from "/public/img/icons/icons-8.png";
export { default as icons_9 } from "/public/img/icons/icons-9.png";
export { default as icons_10 } from "/public/img/icons/icons-10.png";
export { default as icons_11 } from "/public/img/icons/icons-11.png";
export { default as icons_12 } from "/public/img/icons/icons-12.png";

export { default as Logomark_1 } from "/public/img/icons/Logomark-1.png";
export { default as Logomark_2 } from "/public/img/icons/Logomark-2.png";
export { default as Logomark_3 } from "/public/img/icons/Logomark-3.png";
export { default as Logomark_4 } from "/public/img/icons/Logomark-4.png";
export { default as Logomark_5 } from "/public/img/icons/Logomark-5.png";
export { default as Logomark_6 } from "/public/img/icons/Logomark-6.png";

export { default as job_role } from "/public/img/icons/job-role.png";
export { default as job_img } from "/public/img/job-img.png";
export { default as ads_banner } from "/public/img/ads-banner.png";

export { default as news_article_1 } from "/public/img/blog/news-article-1.jpg";
export { default as news_article_2 } from "/public/img/blog/news-article-2.jpg";
export { default as news_article_3 } from "/public/img/blog/news-article-3.jpg";
