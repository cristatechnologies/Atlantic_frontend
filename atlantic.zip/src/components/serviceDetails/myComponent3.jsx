import React from "react";
import Link from "next/link";
import { SlideshowLightbox } from "lightbox.js-react";
import "lightbox.js-react/dist/index.css";

const Roomspics = ({ business_gallery }) => {
  // Check if business_gallery is defined and an array
  if (!Array.isArray(business_gallery)) {
    return <p>No gallery items available.</p>;
  }

  console.log(`${process.env.NEXT_PUBLIC_BASE_URL + item.image}`);

  return (
    <div className="row">
      {business_gallery.map((item, index) => (
        <div className="col-lg-3 col-md-3 col-sm-3" key={index}>
          <div className="review-gallery">
            <SlideshowLightbox>
              {/* Assuming `original` contains the image URL */}
              <img
                className="img-fluid"
                alt={`Gallery item ${index}`}
                src={`${process.env.NEXT_PUBLIC_BASE_URL + item.image}`}
              />
              
            </SlideshowLightbox>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Roomspics;
