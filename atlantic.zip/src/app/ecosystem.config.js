module.exports = {
  apps : [
      {
        name: "demo",
        script: "npm run dev",
        port: 100
      }
  ]
}
