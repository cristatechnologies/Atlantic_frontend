"use client ";

import CategoryComponent from "@/components/CategoryComponent/page";

const categories = () => {
  return (
    <>
      <CategoryComponent />
    </>
  );
};

export default categories;
