import faqComponent from "@/components/faqComponent/page";

const faq = () =>
{
    return (
      <>
      <faqComponent />
      </>
    );
}


export default faq;