"use client";

import YourDealsComponent from "@/components/YourDealsComponent/page";

const YourDeals = () => {
  return (
    <>
      <YourDealsComponent />
    </>
  );
};

export default YourDeals;
