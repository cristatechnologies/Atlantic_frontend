"use client";
import ContactUsComponent from "@/components/ContactUsComponent/page";
import axios from "axios";
import { useState,useEffect } from "react";

const Contact = () => {
 
  return <ContactUsComponent/>;
};

export default Contact;
