"use client";

import HomePage from "@/components/HomePage/page";

export default function Home() {
  return (
    <>
     
      <HomePage />
    </>
  );
}
