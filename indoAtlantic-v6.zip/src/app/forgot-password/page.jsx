import ForgotPasswordComponent from "@/components/forgotPasswordComponent/page";

const ForgotPassword = () => {
  return (
    <>
      <ForgotPasswordComponent />
    </>
  );
};


export default ForgotPassword;