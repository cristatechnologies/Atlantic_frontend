import FaqComponent from "@/components/FaqComponent/page";

const faq = () => {
  return (
    <>
      <FaqComponent />
    </>
  );
};

export default faq;
