'use client'

import LoginComponent from "@/components/LoginComponent/page";
import { useState } from "react";

const Login = () => {
  return <LoginComponent />;
};

export default Login;
