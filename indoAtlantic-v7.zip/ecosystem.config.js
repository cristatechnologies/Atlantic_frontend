module.exports = {
  apps : [
      {
        name: "Atlantic",
        script: "npm run dev",
        port: 1001
      }
  ]
}
