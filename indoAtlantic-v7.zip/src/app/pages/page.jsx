"use client"

import { useRouter } from "next/navigation"

const pages = () =>
{


   const  router = useRouter();
    router.push("/")
    return (

        <>
        </>
    )



}


export default pages;